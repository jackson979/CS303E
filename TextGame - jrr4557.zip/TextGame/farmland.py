#import a python file
import tile
import random

INPUT_FILE_NAME = 'locations.txt'

#function definition with parameters
def read_file(file,dict1):
    #file reading
    first_line = file.readline().rstrip('\n')

    #while loop
    while first_line != "":
        line_list = first_line.split('#')

        new_name = line_list[0]
        new_desc = line_list[1]
        new_ani = line_list[2]

        obj_list = line_list[3].split('&')
        new_obj = []
        for obj in obj_list:
            #using list functionality
            new_obj.append(obj)

        path_list = line_list[4].split('&')
        new_paths = []
        #iterate through a list
        for path in path_list:
            new_paths.append(path)
        
        new_tile = tile.Tile(new_name, new_desc, new_ani, new_obj, new_paths)

        dict1[new_name] = new_tile

        first_line = file.readline().rstrip('\n')
#function definition        
def get_quest():
    #list
    quest = ['Pail(full)','Carton(full)','Bucket(empty)']

    #Random number generator
    x = random.randrange(0,3)

    print("Quest:")
    if x == 0:
        print("You must go and fetch some milk from the cows in the barn. The pail is in the shed.")
        print()
        return quest[0]
    if x == 1:
        print("Go grab the eggs from the chicken coop. Use an egg carton this time please.")
        print()
        return quest[1]
    if x == 2:
        print("Could you walk down to the pig pen and feed them please, there is a full bucket of slop in the shed.")
        print()
        return quest[2]

def setup(name1):
    print("It's a fine Summer morning in Mobile, Alabama. Awoken by the distant crowing of roosters, you notice that there is a note from your father on your nightstand. It reads: " + name1 + ", I have some errands to run in town, so if you could do a couple things for me around the farm that would be fantastic.")
    print()

def display_help():
    #print statement
    print("Basic Command List")
    print()
    print("GOTO <location name>: Takes you to valid location (ex. GOTO Home)")
    print("PICKUP <object name>: Adds the object to the player's inventory")
    print("USE <object name> ON <interactable object>: Used for quest completion")
    print("INVENTORY: Displays list of inventory items.")
    print()
    print("NOTE: Object names, location names, and animal names are all case-sensitive, so write them as displayed by the game.")
    print("i.e.: To move to the shed you must type <goto Shed(out)>")
    print()

def load_tile(loc_name,dict1):
    tile1 = dict1[loc_name]
    desc = tile1.get_description()
    valid_locations = tile1.get_paths()
    valid_interactions = tile1.get_animals()
    valid_objects = tile1.get_objects()

    #assignment statement
    path_str = ""
    for path in valid_locations:
        path_str += path
        path_str += "    "

    obj_str = ""
    if not valid_objects:
        obj_str = "None"
    elif(len(valid_objects) > 1):
        for obj in valid_objects:
            #use +=
            obj_str += obj
            obj_str += "    "
    elif(len(valid_objects) == 1):
        obj_str = valid_objects[0]

    inter_str = ""
    if(valid_interactions != ""):
        inter_str = valid_interactions
    else:
        inter_str = "None"

    print(loc_name + ": " + desc)
    print("Paths: " + path_str)
    #print(len(valid_locations))
    print("Objects: " + obj_str)
    #print(valid_objects)
    print("Things to Interact With: " + inter_str)
    #print(valid_interactions)
    print()

    return tile1

#this whole method is a bunch of nested loops
def get_input(loc_name,dict1,inv):
    command_error = 0
    #try except block
    try:
        tile1 = dict1[loc_name]
        valid_locations = tile1.get_paths()
        valid_interactions = tile1.get_animals()
        valid_objects = tile1.get_objects()
        
        user_input = input("Enter a command: ")
        
        input_list = user_input.split(' ')
    
        if(input_list[0].lower() != 'goto' and input_list[0].lower() != 'pickup' and input_list[0].lower() != 'use' and input_list[0].lower() != 'help' and input_list[0].lower() != "inventory"):
            command_error+=1

        if(input_list[0].lower() == 'goto' and len(input_list) > 2):
            command_error+=1

        if(input_list[0].lower() == 'pickup' and len(input_list) > 2):
            command_error+=1

        if(input_list[0].lower() == 'use' and input_list[2].lower() != 'on'):
            command_error+=1
    except:
        command_error+=1
    
    while(command_error > 0):
        command_error = 0
        try:
            tile1 = dict1[loc_name]
            valid_locations = tile1.get_paths()
            valid_interactions = tile1.get_animals()
            valid_objects = tile1.get_objects()
            
            user_input = input('Invalid command. Enter a valid command: ')
        
            input_list = user_input.split(' ')

            if(input_list[0].lower() != 'goto' and input_list[0].lower() != 'pickup' and input_list[0].lower() != 'use' and input_list[0].lower() != 'help' and input_list[0].lower() != "inventory"):
                command_error+=1

            if(input_list[0].lower() == 'goto' and len(input_list) > 2):
                command_error+=1

            if(input_list[0].lower() == 'pickup' and len(input_list) > 2):
                command_error+=1

            if(input_list[0].lower() == 'use' and input_list[2].lower() != 'on' and len(input_list) > 4):
                command_error+=1

        except:
            command_error+=1
            

    object_error = 0
    interaction_error = 0
    location_error = 0

    #print(valid_locations)

    if(input_list[0].lower() == 'goto' and (input_list[1] not in valid_locations)):
        location_error+=1
    if(input_list[0].lower() == 'pickup' and (input_list[1] not in valid_objects)):
        object_error+=1
    if(input_list[0].lower() == 'use' and (input_list[1] not in inv) and (input_list[3] not in valid_interactions)):
        interaction_error+=1

    while(location_error > 0 or object_error > 0 or interaction_error > 0):
        command_error = 0
        try:
            tile1 = dict1[loc_name]
            valid_locations = tile1.get_paths()
            valid_interactions = tile1.get_animals()
            valid_objects = tile1.get_objects()
            
            user_input = input("Enter a command: ")
            
            input_list = user_input.split(' ')
        
            if(input_list[0].lower() != 'goto' and input_list[0].lower() != 'pickup' and input_list[0].lower() != 'use' and input_list[0].lower() != 'help' and input_list[0].lower() != "inventory"):
                command_error+=1

            if(input_list[0].lower() == 'goto' and len(input_list) > 2):
                command_error+=1

            if(input_list[0].lower() == 'pickup' and len(input_list) > 2):
                command_error+=1

            if(input_list[0].lower() == 'use' and input_list[2].lower() != 'on'):
                command_error+=1
        except:
            command_error+=1
        
        while(command_error > 0):
            command_error = 0
            try:
                tile1 = dict1[loc_name]
                valid_locations = tile1.get_paths()
                valid_interactions = tile1.get_animals()
                valid_objects = tile1.get_objects()
                
                user_input = input('Invalid command. Enter a valid command: ')
            
                input_list = user_input.split(' ')

                if(input_list[0].lower() != 'goto' and input_list[0].lower() != 'pickup' and input_list[0].lower() != 'use' and input_list[0].lower() != 'help' and input_list[0].lower() != "inventory"):
                    command_error+=1

                if(input_list[0].lower() == 'goto' and len(input_list) > 2):
                    command_error+=1

                if(input_list[0].lower() == 'pickup' and len(input_list) > 2):
                    command_error+=1

                if(input_list[0].lower() == 'use' and input_list[2].lower() != 'on' and len(input_list) > 4):
                    command_error+=1

            except:
                command_error+=1
##        tile1 = dict1[loc_name]
##        valid_locations = tile1.get_paths()
##        valid_interactions = tile1.get_animals()
##        valid_objects = tile1.get_objects()

        object_error = 0
        interaction_error = 0
        location_error = 0

        if(input_list[0].lower() == 'goto' and (input_list[1] not in valid_locations)):
            location_error+=1
        if(input_list[0].lower() == 'pickup' and (input_list[1] not in valid_objects)):
            object_error+=1
        if(input_list[0].lower() == 'use' and ((input_list[1] not in inv) or (input_list[3] not in valid_interactions))):
            interaction_error+=1

    return user_input

def interpret_input(loc_name,dict1,inv,ipt):
    try:
        
        tile1 = dict1[loc_name]
        valid_locations = tile1.get_paths()
        valid_interactions = tile1.get_animals()
        valid_objects = tile1.get_objects()

        input_list = ipt.split(' ')

        if(input_list[0].lower() == 'help'):
            #function calling another function
            display_help()
            return(loc_name)

        if(input_list[0].lower() == 'inventory'):
            print(inv)
            return(loc_name)
            
        if(input_list[0].lower() == 'pickup'):
            #print(1)
            inv.append(input_list[1].lower().capitalize())
            #print(2)
            tile1.remove_object(input_list[1])
            #print(3)
            print("You have picked up: " + input_list[1].lower().capitalize())
            return(loc_name)
            
        if(input_list[0].lower() == 'goto'):
            t2 = load_tile(input_list[1].lower().capitalize(),dict1)
            new_name = t2.get_name()
            return(new_name)
        #nested ifs
        elif(input_list[0].lower() == 'use'):
            
            if(input_list[3].lower() == 'lock'):
                
                if(input_list[1].lower() == 'key' and loc_name == "Shed(out)"):
                    print("You have unlocked the shed.")
                    t3 = load_tile("Shed(in)",dict1)
                    new_name = t3.get_name()
                    return(new_name)
                
                else:
                    print("Invalid object.")
                    return(loc_name)
                
            elif(input_list[3].lower() == 'pigs'):

                #if statement
                if(input_list[1].lower() == 'bucket(full)' and loc_name == "Sty"):
                    print("You successfully fed the pigs!")
                    inv.remove("Bucket(full)")
                    inv.append("Bucket(empty)")
                    return(loc_name)
                
                else:
                    print("Invalid object.")
                    return(loc_name)

            elif(input_list[3].lower() == 'cows'):

                if(input_list[1].lower() == 'pail(empty)' and loc_name == "Barn"):
                    print("You successfully milked the cows!")
                    inv.remove("Pail(empty)")
                    inv.append("Pail(full)")
                    return(loc_name)

                else:
                    print("Invalid object.")
                    return(loc_name)

            elif(input_list[3].lower() == 'eggs' and loc_name == "Coop"):

                if(input_list[1].lower() == 'carton(empty)'):
                    print('You successfully retrieved the eggs!')
                    inv.remove("Carton(empty)")
                    inv.append("Carton(full)")

                else:
                    print("Invalid object.")
                    return(loc_name)
            else:
                print("Invalid target.")
                return(loc_name)
                
    except:
        return(loc_name)               
            

def main():
    display_help()
    
    input_file = open(INPUT_FILE_NAME, 'r')

    #dictionary
    location_dict = {}

    read_file(input_file,location_dict)

    name = input("Enter your name: ")
    print()
    setup(name)
    
    quest_item = get_quest()
    inventory = []
    current_location = "Home"

    t1 = load_tile(current_location,location_dict)

    user_input = get_input(current_location,location_dict,inventory)
    
    current_location = interpret_input(current_location,location_dict,inventory,user_input)

    while(quest_item not in inventory):
        
        user_input = get_input(current_location,location_dict,inventory)
    
        current_location = interpret_input(current_location,location_dict,inventory,user_input)

    print()
    print()
    print()
    print("Congratulations! You completed your chore for the day! Time to go watch some Netflix!!!")

main()
