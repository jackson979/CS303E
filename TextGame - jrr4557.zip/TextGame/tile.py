#class
class Tile(object):

    def __init__(self, name, desc, ani, obj, paths):
        self.__name = name
        self.__description = desc
        self.__animals = ani
        
        self.__objects = []

        #for loop
        for item in obj:
            self.__objects.append(item)

        self.__paths = []
        for path in paths:
            self.__paths.append(path)

    def get_name(self):
        return self.__name

    def get_description(self):
        return self.__description

    def get_objects(self):
        return self.__objects

    def remove_object(self,obj):
        self.__objects.remove(obj.lower().capitalize())
            

    def get_paths(self):
        return self.__paths

    def get_animals(self):
        return self.__animals
